// next.config.js
module.exports = {
  images: {
    domains: ['res.cloudinary.com'],
  },
  // Other configurations...
};
